# rust-framebuffer
Basic framebuffer abstraction for Rust.

An example can be found in the examples directory. Use the following command to compile and run:
`sudo cargo run --release --example rust-logo`
Sudo is required the access the framebuffer device.

Basic documentation is available: http://roysten.github.io/rust-framebuffer/target/doc/framebuffer/.
